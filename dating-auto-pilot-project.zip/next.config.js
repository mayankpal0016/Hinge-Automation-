/** @type {import('next').NextConfig} */
const nextConfig = {
  // make sure the PDF is bundled with the webhook on Vercel
  outputFileTracingIncludes: {
    '/api/razorpay-webhook': ['./public/customer-guide.pdf'],
  },
  // show the landing page at the home page
  async rewrites() {
    return {
      beforeFiles: [{ source: '/', destination: '/landing.html' }],
    };
  },
};
module.exports = nextConfig;
