// POST /api/razorpay-webhook
// Razorpay "payment.captured" -> verify signature -> confirm payment with Razorpay -> email the PDF once.
//
// Environment variables (all server-side, set in Vercel):
//   RAZORPAY_WEBHOOK_SECRET   the secret typed when creating the webhook in Razorpay (NOT your API key secret)
//   RESEND_API_KEY
//   EMAIL_FROM                e.g. "Your Brand <hello@yourdomain.com>" or "onboarding@resend.dev" for testing
//   RAZORPAY_KEY_ID           your EXISTING Razorpay key id (read only, used to confirm the payment)
//   RAZORPAY_KEY_SECRET       your EXISTING Razorpay key secret (read only)
// Optional:
//   EXPECTED_AMOUNT_PAISE     default 39900 (Rs 399)
//   EMAIL_TEST_TO             if set, EVERY email goes to this address only (safe testing with onboarding@resend.dev)
//   SITE_URL                  e.g. https://yourdomain.com, used only if the PDF is too large to attach
//   UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN   (or KV_REST_API_URL / KV_REST_API_TOKEN)
//                             durable duplicate protection, see README
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const PDF_FILE = 'customer-guide.pdf';
const MAX_ATTACH_BYTES = 10 * 1024 * 1024; // attach only if the PDF is under 10 MB
const reply = (text, status = 200) => new Response(text, { status });

// ---------- durable duplicate protection (optional Redis over REST, no extra npm package) ----------
const REDIS_URL = () => process.env.UPSTASH_REDIS_REST_URL || process.env.KV_REST_API_URL;
const REDIS_TOKEN = () => process.env.UPSTASH_REDIS_REST_TOKEN || process.env.KV_REST_API_TOKEN;
async function redis(cmd) {
  const res = await fetch(REDIS_URL(), {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + REDIS_TOKEN(), 'Content-Type': 'application/json' },
    body: JSON.stringify(cmd),
  });
  if (!res.ok) throw new Error('Redis error ' + res.status);
  return (await res.json()).result;
}
const redisConfigured = () => Boolean(REDIS_URL() && REDIS_TOKEN());

export async function POST(request) {
  const env = process.env;
  if (!env.RAZORPAY_WEBHOOK_SECRET || !env.RESEND_API_KEY || !env.EMAIL_FROM || !env.RAZORPAY_KEY_ID || !env.RAZORPAY_KEY_SECRET) {
    console.error('razorpay-webhook: missing environment variables');
    return reply('Server not configured', 500);
  }

  // 1. Signature check on the RAW body
  const raw = await request.text();
  const sig = request.headers.get('x-razorpay-signature') || '';
  const expected = crypto.createHmac('sha256', env.RAZORPAY_WEBHOOK_SECRET).update(raw).digest('hex');
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return reply('Invalid signature', 400);

  let event;
  try { event = JSON.parse(raw); } catch { return reply('Bad JSON', 400); }
  if (event.event !== 'payment.captured') return reply('Ignored event');

  const paymentId = event && event.payload && event.payload.payment && event.payload.payment.entity && event.payload.payment.entity.id;
  if (!/^pay_[A-Za-z0-9]+$/.test(String(paymentId || ''))) return reply('No payment id', 400);

  // 2. Do not trust the webhook body for details: confirm the payment directly with Razorpay
  const auth = Buffer.from(env.RAZORPAY_KEY_ID + ':' + env.RAZORPAY_KEY_SECRET).toString('base64');
  const pRes = await fetch('https://api.razorpay.com/v1/payments/' + paymentId, { headers: { Authorization: 'Basic ' + auth } });
  if (!pRes.ok) {
    console.error('Could not fetch payment', paymentId, pRes.status);
    return reply('Could not verify payment, retry', 500); // Razorpay will retry
  }
  const p = await pRes.json();
  const minAmount = Number(env.EXPECTED_AMOUNT_PAISE || 39900);
  if (p.id !== paymentId || p.status !== 'captured' || p.currency !== 'INR' || Number(p.amount) < minAmount) {
    console.warn('Payment failed verification, not delivering', paymentId, p.status, p.amount);
    return reply('Payment not eligible');
  }
  const customerEmail = String(p.email || '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(customerEmail)) {
    console.warn('No valid email on payment, deliver manually', paymentId, p.order_id || '');
    return reply('No email, deliver manually');
  }

  // 3. Durable duplicate protection: claim this payment id before sending
  const claimKey = 'pdf-sent:' + paymentId;
  let claimed = false;
  if (redisConfigured()) {
    try {
      const r = await redis(['SET', claimKey, new Date().toISOString(), 'NX', 'EX', String(60 * 60 * 24 * 90)]);
      if (r !== 'OK') return reply('Duplicate, already handled');
      claimed = true;
    } catch (e) {
      console.error('Redis unavailable', e.message);
      return reply('Storage unavailable, retry', 500);
    }
  } else {
    console.warn('No Redis configured: relying on Resend idempotency key only (covers about 24h of retries)');
  }

  // 4. Build the email
  const to = env.EMAIL_TEST_TO ? env.EMAIL_TEST_TO.trim() : customerEmail;
  const pdfPath = path.join(process.cwd(), 'public', PDF_FILE);
  let attachments, downloadHtml = '';
  try {
    const size = fs.statSync(pdfPath).size;
    if (size <= MAX_ATTACH_BYTES) {
      attachments = [{ filename: PDF_FILE, content: fs.readFileSync(pdfPath).toString('base64') }];
    } else if (env.SITE_URL) {
      downloadHtml = '<p><a href="' + env.SITE_URL.replace(/\/$/, '') + '/' + PDF_FILE + '">Download your guide</a></p>';
    }
  } catch (e) {
    console.error('PDF not found at', pdfPath, e.message);
    if (claimed) await redis(['DEL', claimKey]).catch(() => {});
    return reply('PDF missing', 500);
  }

  const amountRs = (Number(p.amount) / 100).toFixed(2);
  const html =
    '<div style="font-family:Arial,Helvetica,sans-serif;max-width:520px;margin:0 auto;color:#16151B;line-height:1.6">' +
    '<h2 style="margin:0 0 12px">Payment confirmed</h2>' +
    '<p>Thank you for your purchase. We have received your payment of <b>Rs ' + amountRs + '</b>.</p>' +
    (attachments ? '<p>Your guide is attached to this email as a PDF.</p>' : downloadHtml) +
    '<p style="font-size:13px;color:#6B6877">Payment ID: ' + paymentId + '<br>This is your personal copy, please do not share it.</p>' +
    '<p style="font-size:13px;color:#6B6877">If anything is wrong, just reply to this email.</p></div>';

  // 5. Send
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: 'Bearer ' + env.RESEND_API_KEY,
      'Content-Type': 'application/json',
      'Idempotency-Key': 'guide-' + paymentId,
    },
    body: JSON.stringify({
      from: env.EMAIL_FROM,
      to: [to],
      subject: (env.EMAIL_TEST_TO ? '[TEST] ' : '') + 'Your payment is confirmed: here is your guide',
      html,
      ...(attachments ? { attachments } : {}),
    }),
  });
  if (!res.ok) {
    console.error('Resend failed', res.status, await res.text());
    if (claimed) await redis(['DEL', claimKey]).catch(() => {}); // release so Razorpay's retry can try again
    return reply('Email failed, will retry', 500);
  }
  return reply('Sent');
}
