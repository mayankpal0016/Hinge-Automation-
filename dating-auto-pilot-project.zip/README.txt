DATING AUTO PILOT: complete project (landing page + Razorpay webhook + PDF email)
=================================================================================
Use this as a NEW GitHub repo / NEW Vercel project.
If you already have a website project, do NOT replace its package.json or next.config.js with these.
In that case only add app/api/razorpay-webhook/route.js and public/customer-guide.pdf.

Files:
  package.json                         Next.js 15 project (dependencies: next, react, react-dom)
  package-lock.json                    exact versions (keep it)
  next.config.js                       shows the landing page at "/" and bundles the PDF with the webhook
  .gitignore                           keeps secrets and build files out of GitHub
  public/landing.html                  your landing page
  public/customer-guide.pdf            your PDF
  app/api/razorpay-webhook/route.js    the webhook

Deploy: GitHub > Add file > Upload files (the whole folder contents, including app/ and public/) > Commit.
Vercel > Add New > Project > pick the repo > Framework: Next.js (auto) > Deploy.
Then add the environment variables from the webhook's header comment (RAZORPAY_WEBHOOK_SECRET, RESEND_API_KEY,
EMAIL_FROM, RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET) and Redeploy.
Webhook URL: https://YOUR-DOMAIN/api/razorpay-webhook   (event: payment.captured)
Never upload a .env file to GitHub.
